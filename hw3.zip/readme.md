### Instructions to run

Algos 1 and 2 work fine out of the box. However, you need to download the rockyou training data and add it to the `data` folder as `passwords.txt` in order for algo 3 to run.
